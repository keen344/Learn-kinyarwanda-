LEARN KINYARWANDA - VERSION 1
Open index.html in a browser to view the website.

Next steps:
1. Add more lessons.
2. Add user accounts.
3. Choose a legal payment provider available to the project owner.
4. Connect Premium access to successful payments.
5. Publish the site online with a custom domain.
